const express = require('express');
const mongoose = require('mongoose');
const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

mongoose.connect('mongodb://127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+2.0.1', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const Product = mongoose.model('Product', {
  name: String,
  price: Number,
  quantity: Number,
  address: String,
});

// Define a Mongoose model for sell data
const Sell = mongoose.model('Sell', {
  name: String,
  price: Number,
  quantity: Number,
  address: String,
});

app.get('/', (req, res) => {
  res.render('home');
});

app.get('/product', (req, res) => {
  res.render('product');
});

app.post('/product', async (req, res) => {
  try {
    const { name, price, quantity, address } = req.body;
    const product = new Product({ name, price, quantity, address });
    await product.save();
    res.redirect('/');
  } catch (err) {
    res.status(500).send('Error saving product to the database.');
  }
});

app.get('/sell', (req, res) => {
  res.render('sell');
});

app.post('/sell', async (req, res) => {
  try {
    // Parse data from the request body
    const { name, price, quantity, address } = req.body;

    // Create a new instance of the Sell model
    const sell = new Sell({ name, price, quantity, address });

    // Save the sell data to the database
    await sell.save();

    // Redirect to a confirmation page or home
    res.redirect('/');
  } catch (err) {
    // Handle errors
    res.status(500).send('Error saving sell data to the database.');
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
