const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Task = require('./models/Task');

const app = express();
const port = process.env.PORT || 3000;

mongoose.connect('mongodb://127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+2.0.1', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.redirect('/dashboard');
});

app.get('/dashboard', async (req, res) => {
    const tasks = await Task.find();
    res.render('dashboard', { tasks });
});

app.get('/add-task', (req, res) => {
    res.render('add-task');
});

app.post('/add-task', async (req, res) => {
    const { title, description, status } = req.body;
    const task = new Task({ title, description, status });
    await task.save();
    res.redirect('/dashboard');
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
