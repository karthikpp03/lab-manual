// AppRouter.js

import React, { useState } from 'react';
import { BrowserRouter as Router, Switch, Route, Redirect } from 'react-router-dom';
import Signup from './components/Signup';
import TodoList from './components/TodoList';

const AppRouter = () => {
  const [user, setUser] = useState(localStorage.getItem('user') || '');

  const handleSignUp = (username) => {
    localStorage.setItem('user', username);
    setUser(username); // This line was missing
  };

  return (
    <Router>
      <Switch>
        <Route exact path="/">
          {user ? <TodoList user={user} /> : <Redirect to="/signup" />}
        </Route>
      </Switch>
    </Router>
  );
};

export default AppRouter;
