import React, { useState } from 'react';
import TodoList from './TodoList';

const Home = ({ username, todos, onAddTodo, onDeleteTodo }) => {
  const [newTodo, setNewTodo] = useState('');

  const handleAddTodo = () => {
    if (newTodo.trim() !== '') {
      onAddTodo(newTodo);
      setNewTodo('');
    }
  };

  return (
    <div className="home">
      <h1>Welcome, {username}!</h1>
      <div className="add-todo">
        <input
          type="text"
          placeholder="Enter a new task"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
        />
        <button onClick={handleAddTodo}>Add</button>
      </div>
      <TodoList todos={todos} onDelete={onDeleteTodo} />
    </div>
  );
};

export default Home;
