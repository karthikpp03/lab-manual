import React, { useState, useEffect } from 'react';
import TodoList from './TodoList';
import Login from './Login';


const TodoApp = () => {
  const [user, setUser] = useState(null);
  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState('');

  useEffect(() => {
    if (user) {
      const userTodos = JSON.parse(localStorage.getItem(user)) || [];
      setTodos(userTodos);
    }
  }, [user]);

  const handleLogin = (username) => {
    setUser(username);
  };


  const addTodo = () => {
    if (newTodo.trim() !== '') {
      const updatedTodos = [...todos, newTodo];
      setTodos(updatedTodos);
      updateLocalStorage(user, updatedTodos);
      setNewTodo('');
    }
  };

  const updateTodo = (oldTodo, newTodo) => {
    const updatedTodos = todos.map((todo) => (todo === oldTodo ? newTodo : todo));
    setTodos(updatedTodos);
    updateLocalStorage(user, updatedTodos);
  };

  const deleteTodo = (todo) => {
    const updatedTodos = todos.filter((item) => item !== todo);
    setTodos(updatedTodos);
    updateLocalStorage(user, updatedTodos);
  };

  const updateLocalStorage = (username, updatedTodos) => {
    localStorage.setItem(username, JSON.stringify(updatedTodos));
  };

  return (
    <div className="app">
      {user ? (
        <>
          <h1>Welcome, {user}!</h1>
          <TodoList user={user} todos={todos} onUpdate={updateTodo} onDelete={deleteTodo} />
        </>
      ) : (
        <>
          <h1>TO-DO List App</h1>
          <Login onLogin={handleLogin} />
        </>
      )}
    </div>
  );
};

export default TodoApp;
