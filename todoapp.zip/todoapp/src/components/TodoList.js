import React, { useState, useEffect } from 'react';
import TodoItem from './TodoItem';

const TodoList = ({ user }) => {
  const [todoItems, setTodoItems] = useState([]);
  const [newTodo, setNewTodo] = useState('');

  useEffect(() => {
    const storedTodos = JSON.parse(localStorage.getItem(`todos_${user}`)) || [];
    setTodoItems(storedTodos);
  }, [user]);

  const saveTodoItems = (items) => {
    localStorage.setItem(`todos_${user}`, JSON.stringify(items));
  };

  const handleAddTodo = () => {
    if (newTodo) {
      const updatedTodos = [...todoItems, { id: Date.now(), text: newTodo }];
      setTodoItems(updatedTodos);
      saveTodoItems(updatedTodos);
      setNewTodo('');
    }
  };

  const handleDeleteTodo = (id) => {
    const updatedTodos = todoItems.filter((item) => item.id !== id);
    setTodoItems(updatedTodos);
    saveTodoItems(updatedTodos);
  };

  return (
    <div>   
      <input
        type="text"
        placeholder="New Todo"
        value={newTodo}
        onChange={(e) => setNewTodo(e.target.value)}
      />
      <button onClick={handleAddTodo}>Add</button>
      <ul>
        {todoItems.map((item) => (
          <TodoItem key={item.id} item={item} onDelete={handleDeleteTodo} />
        ))}
      </ul>
    </div>
  );
};

export default TodoList;
