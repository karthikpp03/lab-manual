import React from 'react';

const TodoItem = ({ item, onDelete }) => {
  return (
    <li>
      {item.text}
      <button onClick={() => onDelete(item.id)}>Delete</button>
    </li>
  );
};

export default TodoItem;
    