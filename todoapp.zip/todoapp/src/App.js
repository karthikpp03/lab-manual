import React, { useState } from 'react';
import Login from './components/Login';
import TodoList from './components/TodoList';

const App = () => {
  const [user, setUser] = useState(null);

  return (
    <div className="App">
      {user ? <TodoList user={user} /> : <Login setUser={setUser} />}
    </div>
  );
};

export default App;
