const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(bodyParser.json());

mongoose.connect('mongodb://127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+2.0.1', { useNewUrlParser: true, useUnifiedTopology: true });

const questionSchema = new mongoose.Schema({
  questionText: String,
  options: [String],
  correctAnswer: Number,
});

const Question = mongoose.model('Question', questionSchema);

const responseSchema = new mongoose.Schema({
  userId: String,
  answers: [{ questionId: String, selectedOption: Number }],
});

const Response = mongoose.model('Response', responseSchema);

app.use(express.static('public'));

app.get('/questions', async (req, res) => {
  try {
    const randomQuestions = await Question.aggregate([{ $sample: { size: 5 } }]);
    res.json(randomQuestions);
  } catch (error) {
    res.status(500).json({ error: 'Unable to fetch questions' });
  }
});

app.post('/submit', async (req, res) => {
  const { userId, answers } = req.body;

  try {
    const response = new Response({ userId, answers });
    await response.save();

    // Calculate the number of correct answers here
    let correctAnswers = 0;
    for (const answer of answers) {
      const question = await Question.findById(answer.questionId);
      if (question.correctAnswer === parseInt(answer.selectedOption)) {
        correctAnswers++;
      }
    }

    res.json({ correctAnswers });
  } catch (error) {
    res.status(500).json({ error: 'Unable to submit responses' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
