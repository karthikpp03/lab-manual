let isSubmitComplete = false; // Track if the submission is complete

async function fetchQuestions() {
  const response = await fetch('/questions');
  const questions = await response.json();
  const questionsDiv = document.getElementById('questions');

  questions.forEach((question, index) => {
    const questionDiv = document.createElement('div');
    questionDiv.classList.add('question');
    questionDiv.innerHTML = `
        <p>${index + 1}. ${question.questionText}</p>
        <form>
            ${question.options.map((option, optionIndex) => `
                <label>
                    <input type="radio" name="q${index}" value="${optionIndex}">
                    ${option}
                </label><br>
            `).join('')}
        </form>
    `;
    questionsDiv.appendChild(questionDiv);
  });
}

async function submitResponses(event) {
  event.preventDefault();

  if (isSubmitComplete) {
    // If the submission is already complete, refresh the page
    window.location.reload();
    return;
  }

  const answers = [];
  const userId = 'user123'; // Replace with actual user authentication

  const questions = document.querySelectorAll('form');
  questions.forEach((form, index) => {
    const selectedOption = form.querySelector(`input[name="q${index}"]:checked`);
    if (selectedOption) {
      answers.push({ questionId: index, selectedOption: selectedOption.value });
    }
  });

  if (answers.length !== 5) {
    alert('Please answer all 5 questions.');
    return;
  }

  const response = await fetch('/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ userId, answers }),
  });

  const result = await response.json();
  alert(`You got ${result.correctAnswers} out of 5 correct!`);

  isSubmitComplete = true; // Mark the submission as complete
}

fetchQuestions();

const submitButton = document.getElementById('submit');
submitButton.addEventListener('click', submitResponses);
