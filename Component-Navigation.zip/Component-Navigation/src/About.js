import React from 'react';
import { Link } from 'react-router-dom';
const About = () => {
  return <div>This is the About page 
    <br/><br/>

    <Link to="/">Home </Link><br/><br/>
    <Link to="/about">About </Link>
  </div>;
};

export default About;
