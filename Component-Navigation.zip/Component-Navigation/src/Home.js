import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return <div>
    This is the Home page
    <br/><br/>
    <Link to="/">Home </Link> <br/><br/>
    <Link to="/about">About </Link>
  </div>;
};

export default Home;
