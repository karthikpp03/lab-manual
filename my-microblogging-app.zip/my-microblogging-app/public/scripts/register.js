// register.js

document.addEventListener('DOMContentLoaded', function () {
    const registerForm = document.querySelector('.register-form');

    // Event listener for submitting the registration form
    registerForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const username = event.target.username.value.trim();
        const password = event.target.password.value;

        // In a real application, you would send an AJAX request to the server to register the user
        // For simplicity, we'll just log the registration details for now
        console.log('Username:', username);
        console.log('Password:', password);

        // Redirect to the login page or handle registration errors
    });
});
