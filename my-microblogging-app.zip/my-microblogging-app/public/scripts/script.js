// Function to add a new post to the feed
function addPost(username, content, postId) {
  const post = document.createElement('div');
  post.classList.add('post');
  post.innerHTML = `
    <p><strong>${username}</strong></p>
    <p>${content}</p>
    <button class="delete-button" data-post-id="${postId}">Delete</button>
  `;
  postFeed.appendChild(post);
  
  // Add event listener for delete buttons
  const deleteButtons = post.querySelectorAll('.delete-button');
  deleteButtons.forEach(deleteButton => {
    deleteButton.addEventListener('click', async (event) => {
      event.preventDefault();
      const postId = event.target.dataset.postId;
  
      try {
        // Send a POST request to the delete-post route with the postId parameter
        const response = await fetch(`/delete-post/${postId}`, {
          method: 'POST',
        });
  
        if (response.ok) {
          // Post was successfully deleted, remove it from the UI
          const postElement = event.target.closest('.post');
          postElement.remove();
        } else {
          console.error('Failed to delete post');
        }
      } catch (error) {
        console.error(error);
      }
    });
  });
}

// Event listener for submitting a new post
postForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const content = event.target.content.value.trim();

  // Check if the content is not empty
  if (content) {
    try {
      // Send a POST request to create a new post
      const response = await fetch('/post', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content }),
      });

      if (response.ok) {
        // Post was successfully created, add it to the UI
        const newPost = await response.json();
        addPost('Your Username', newPost.content, newPost._id);

        // Clear the input field
        event.target.content.value = '';
      } else {
        console.error('Failed to create post');
      }
    } catch (error) {
      console.error(error);
    }
  }
});
