document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.querySelector('.login-form');

    // Event listener for submitting the login form
    loginForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const username = event.target.username.value.trim();
        const password = event.target.password.value;

        // In a real application, you would send an AJAX request to the server for authentication
        // For simplicity, we'll just log the credentials for now
        console.log('Username:', username);
        console.log('Password:', password);

        // Redirect to the user's profile page or handle authentication errors
    });
});
