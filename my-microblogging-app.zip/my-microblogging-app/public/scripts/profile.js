// profile.js

document.addEventListener('DOMContentLoaded', async function () {
    const postFeed = document.querySelector('.post-feed');

    // Function to add a new post to the feed
    function addPost(username, content) {
        const post = document.createElement('div');
        post.classList.add('post');
        post.innerHTML = `
            <p><strong>${username}</strong></p>
            <p>${content}</p>
        `;
        postFeed.appendChild(post);
    }

    try {
        // Send an AJAX GET request to fetch user posts from the server
        const response = await fetch('/user-posts', {
            method: 'GET',
        });

        if (response.ok) {
            // Parse the response JSON
            const data = await response.json();

            // Iterate through user posts and add them to the feed
            data.posts.forEach(post => {
                addPost(data.user.username, post.content);
            });
        } else {
            console.error('Failed to fetch user posts');
        }
    } catch (error) {
        console.error(error);
    }

    // Add more user-related functionality as needed
});
