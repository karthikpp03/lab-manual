const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');
const Order = require('./models/Order');

const app = express();
const port = process.env.PORT || 3000;

// Configure Multer for handling file uploads
const storage = multer.diskStorage({
    destination: (req, file, callback) => {
      callback(null, 'uploads');
    },
    filename: (req, file, callback) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const fileExtension = path.extname(file.originalname);
      callback(null, file.fieldname + '-' + uniqueSuffix + fileExtension);
    },
  });
  

const upload = multer({ storage: storage });

// Connect to MongoDB (replace 'your-mongodb-uri' with your MongoDB connection URI)
mongoose.connect('mongodb://127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+2.0.1', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('MongoDB connection error:', error);
  });

// Serve static files (e.g., images)
app.use('/uploads', express.static('uploads'));

// Set up middleware to handle form data
app.use(express.urlencoded({ extended: true }));

// Set the view engine to EJS (replace with your preferred view engine if needed)
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Render the food order form
app.get('/', (req, res) => {
  res.render('index');
});

// Handle form submission
app.post('/submit-order', upload.single('foodImage'), async (req, res) => {
  try {
    const { foodName, quantity, additionalInfo } = req.body;
    const foodImage = req.file ? req.file.filename : null;

    // Create a new order document
    const order = new Order({
      foodName,
      quantity,
      additionalInfo,
      foodImage,
    });

    // Save the order to MongoDB
    await order.save();

    res.send('Order placed successfully!');
  } catch (error) {
    console.error('Error placing order:', error);
    res.status(500).send('An error occurred while placing the order.');
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
