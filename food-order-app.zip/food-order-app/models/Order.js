// models/Order.js
const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  foodName: String,
  quantity: Number,
  additionalInfo: String,
  foodImage: String,
});

const Order = mongoose.model('Order', orderSchema);

module.exports = Order;
