const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();

// Serve static files (HTML, CSS, JavaScript) from the "public" directory
app.use(express.static('public'));

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/?directConnection=true&serverSelectionTimeoutMS=2000&appName=mongosh+2.0.1', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;

db.on('error', (err) => {
    console.error(`MongoDB connection error: ${err}`);
});
db.once('open', () => {
    console.log('Connected to MongoDB');
});

// Define a root route
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// Middleware
app.use(bodyParser.json());

// Define routes
const leaveRoutes = require('./routes/leave');
app.use('/leave', leaveRoutes);

// Start the server
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
