const mongoose = require('mongoose');

const leaveSchema = new mongoose.Schema({
    type: String,
    startDate: Date,
    endDate: Date,
    reason: String,
});

const Leave = mongoose.model('Leave', leaveSchema);

module.exports = Leave;
