const Leave = require('../models/leave');

// Create a new leave request
exports.createLeave = (req, res) => {
    const { type, startDate, endDate, reason } = req.body;
    const newLeave = new Leave({
        type,
        startDate,
        endDate,
        reason,
    });

    newLeave.save((err) => {
        if (err) {
            console.error(`Error saving leave request: ${err}`);
            res.status(500).send('Error saving leave request');
        } else {
            res.status(201).send('Leave request saved successfully');
        }
    });
};

// Get available leaves with remaining leave days using async/await
exports.getLeaves = async (req, res) => {
    try {
        const leaves = await Leave.find({});
        // Calculate remaining leave days for each leave request
        const leavesWithRemainingDays = leaves.map((leave) => ({
            ...leave._doc,
            remainingDays: calculateRemainingLeaves(leave.type),
        }));
        res.json(leavesWithRemainingDays);
    } catch (error) {
        console.error('Error fetching leaves:', error);
        res.status(500).send('Error fetching leaves');
    }
};

// Calculate remaining leave days (simplified example, update as per your organization's policy)
function calculateRemainingLeaves(leaveType) {
    // You can retrieve the user's leave balance from your data source and perform the calculation here
    if (leaveType === 'medical') {
        // Example calculation for medical leave
        const totalMedicalLeaves = 10; // Total medical leave days allowed
        const usedMedicalLeaves = 2;  // Number of medical leave days already used
        return totalMedicalLeaves - usedMedicalLeaves;
    } else {
        return 0; // No remaining leave for other types
    }
}
// ... (your existing code)

document.addEventListener('DOMContentLoaded', function () {
    const leaveForm = document.getElementById('leave-form');
    const leaveItems = document.getElementById('leave-items');

    // Function to display leave requests and remaining leave days
    function displayLeaveRequests(leaves) {
        leaveItems.innerHTML = ''; // Clear the list
        leaves.forEach((leave) => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `<strong>${leave.type} Leave</strong><br>From: ${leave.startDate}<br>To: ${leave.endDate}<br>Reason: ${leave.reason}<br>Remaining Leave Days: ${leave.remainingDays}`;
            leaveItems.appendChild(listItem);
        });
    }

    // Fetch and display available leaves when the page loads
    fetch('/leave')
        .then((response) => response.json())
        .then((data) => {
            displayLeaveRequests(data);
        })
        .catch((error) => {
            console.error('Error fetching leaves:', error);
        });

    // Event listener for leave submission
    leaveForm.addEventListener('submit', function (e) {
        e.preventDefault();
        // ... (your existing code for submitting a new leave request)
    });
});
