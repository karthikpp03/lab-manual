const express = require('express');
const router = express.Router();
const leaveController = require('../controllers/leave');

// Create a new leave request
router.post('/', leaveController.createLeave);

// Get available leaves
router.get('/', leaveController.getLeaves);

module.exports = router;
