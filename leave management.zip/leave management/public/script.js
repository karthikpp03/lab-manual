document.addEventListener('DOMContentLoaded', function () {
    const leaveForm = document.getElementById('leave-form');
    const leaveItems = document.getElementById('leave-items');

    // Event listener for leave submission
    leaveForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const leaveType = document.getElementById('leave-type').value;
        const startDate = document.getElementById('start-date').value;
        const endDate = document.getElementById('end-date').value;
        const reason = document.getElementById('reason').value;

        // You can send a POST request to your backend to save the leave request here
        // For demonstration purposes, we'll just add it to the list
        const listItem = document.createElement('li');
        listItem.innerHTML = `<strong>${leaveType} Leave</strong><br>From: ${startDate}<br>To: ${endDate}<br>Reason: ${reason}`;
        leaveItems.appendChild(listItem);

        // Clear the form
        leaveForm.reset();
    });

    // Function to fetch and display available leave requests
    function fetchAvailableLeaves() {
        fetch('/leave') // Assuming your backend route for getting leaves is '/leave'
            .then((response) => response.json())
            .then((data) => {
                leaveItems.innerHTML = ''; // Clear the list
                data.forEach((leave) => {
                    const listItem = document.createElement('li');
                    listItem.innerHTML = `<strong>${leave.type} Leave</strong><br>From: ${leave.startDate}<br>To: ${leave.endDate}<br>Reason: ${leave.reason}`;
                    leaveItems.appendChild(listItem);
                });
            })
            .catch((error) => {
                console.error('Error fetching leaves:', error);
            });
    }

    // Fetch and display available leaves when the page loads
    fetchAvailableLeaves();
});
// ... (previous code)

document.addEventListener('DOMContentLoaded', function () {
    const leaveForm = document.getElementById('leave-form');
    const leaveItems = document.getElementById('leave-items');

    // Function to display leave requests and remaining leave days
    function displayLeaveRequests(leaves) {
        leaveItems.innerHTML = ''; // Clear the list
        leaves.forEach((leave) => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `<strong>${leave.type} Leave</strong><br>From: ${leave.startDate}<br>To: ${leave.endDate}<br>Reason: ${leave.reason}<br>Remaining Leave Days: ${leave.remainingDays}`;
            leaveItems.appendChild(listItem);
        });
    }

    // Fetch and display available leaves when the page loads
    fetch('/leave')
        .then((response) => response.json())
        .then((data) => {
            displayLeaveRequests(data);
        })
        .catch((error) => {
            console.error('Error fetching leaves:', error);
        });

    // Event listener for leave submission
    leaveForm.addEventListener('submit', function (e) {
        e.preventDefault();
        // ... (previous code)
    });
});
