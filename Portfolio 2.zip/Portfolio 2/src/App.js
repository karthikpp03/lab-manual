import React from 'react';
import './App.css';
import Home from './Home';
import Skills from './Skills';
import About from './About';

function App() {
  return (
    <div className="app">
      <Home />
      <Skills />
      <About />
    </div>
  );
}

export default App;
