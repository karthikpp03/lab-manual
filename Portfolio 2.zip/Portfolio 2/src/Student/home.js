import React from 'react';
import './Student/home.css';

function home(props) {
    return (
        <div className="div">
            <h1 className="h1">Prathyusha Engineering College</h1>
            <p>  Student Management System</p>

        </div>
    );
}

export default home;