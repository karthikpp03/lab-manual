import React from 'react';
import './About.css';

const About = () => {
  return (
    <section className="about">
      <h2 className="h2">About Me</h2>
      <p className="p">
        I am a passionate Full Stack Developer specializing in the MERN stack.
        With several years of experience in web development, I have built
        numerous applications that showcase my expertise and skills.
      </p>
    </section>
  );
};

export default About;
