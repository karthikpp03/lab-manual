import React from 'react';
import './Home.css';

const Home = () => {
  return (
    <section className="home">
      <h1>Welcome to My Portfolio</h1>
      <p>I am a Full Stack Developer with expertise in the MERN stack.</p>
    </section>
  );
};

export default Home;
